In this lab, i've created multiple VM's using Count parameters. 

chanvm.tf.backup -- this has the code where i've used just count paramerters wtih copy.index to add the number against VMname. 

to get the more VM, just need to increase the VM Count and i'll add that number of VMs. 


-----------------------------------------------------------------------------------------

chanvm.tf  -- In this one i've used elelemnt function. 
element(var.vm_name,count.index)

variable has
variable "vm_name" { type = list }

tfvars has 
vm_name                   = ["AccuprodVM01","AccuprodVM02","AccuprodVM03","AccuprodVM04"]


so with this element function, its pikcing up defined VMnames from the list array defined in tfvars. this is to achieve if i've to deploy VM with different names and not in sequence which i can't generate dynamically. 

Also, in this example i've added one data disk only to VM01. disk can also be increased using same count function. 